# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['selenium_tools',
 'selenium_tools.page_objects',
 'selenium_tools.selenium_driver',
 'selenium_tools.selenium_plus',
 'selenium_tools.testes']

package_data = \
{'': ['*']}

install_requires = \
['selenium>=4.1.0,<5.0.0', 'webdriver-manager>=3.5.2,<4.0.0']

setup_kwargs = {
    'name': 'selenium-tools',
    'version': '0.1.0',
    'description': 'Facilitando a vida dos desenvolvedores da digitalpath.',
    'long_description': None,
    'author': 'Rodrigoneal',
    'author_email': 'rodrigho2006@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
