from selenium_tools import Page, Element


def test_se_page_existe():
    assert Page

def test_se_element_existe():
    assert Element